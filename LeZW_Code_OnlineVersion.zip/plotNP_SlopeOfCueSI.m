function fig1 = plotNP_SlopeOfCueSI(NP_MD,NP_OFC)
%% plot figure 3a-b

MD = NP_MD.nBlock.cueSI_slope;
OFC = NP_OFC.nBlock.cueSI_slope;

fig1 = figure('Position',[100 100 1000 350],'Color','w');
subplot(1,2,1);hold on;box off;
TimeStamps = -1+0.1/2:0.1:2-0.1/2;
MD_hist = histcounts(MD,-1:0.1:2)./size(MD,1)*100;
OFC_hist = histcounts(OFC,-1:0.1:2)./size(OFC,1)*100;
bar(TimeStamps,MD_hist,'EdgeColor','none','FaceColor','#F8C0B1','FaceAlpha',0.5);
bar(TimeStamps,OFC_hist,'EdgeColor','none','FaceColor','#89D6B4','FaceAlpha',0.5,'BarWidth',0.5);
plot([0 0],ylim,'--r');
xlabel('Regression slope of cue SI on d''');
ylabel('Percentage of cells (%)');
legend('MD','OFC');
subplot(1,2,2);hold on;box off;
MD_mean_CueSI = mean(MD);
MD_sem_CueSI = std(MD)/sqrt(size(MD,1));
OFC_mean_CueSI = mean(OFC);
OFC_sem_CueSI = std(OFC)/sqrt(size(OFC,1));
bar(1,MD_mean_CueSI,'EdgeColor','none','FaceColor','#F8C0B1');
errorbar(1,MD_mean_CueSI,MD_sem_CueSI,'CapSize',0);
bar(2,OFC_mean_CueSI,'EdgeColor','none','FaceColor','#89D6B4');
errorbar(2,OFC_mean_CueSI,OFC_sem_CueSI,'CapSize',0);
set(gca,'YLim',[0 0.3],'XLim',[0.25 2.75],'XTick',[1 2],'XTickLabel',{'MD','OFC'});
MD_signrank0 = signrank(MD);
OFC_signrank0 = signrank(OFC);
tit_txt = sprintf('MD=%.3e;OFC=%.3e',MD_signrank0,OFC_signrank0);
title(tit_txt);
ylabel('Regression slope of cue SI on d''');

sgtitle('fig. 3a-b');
end

