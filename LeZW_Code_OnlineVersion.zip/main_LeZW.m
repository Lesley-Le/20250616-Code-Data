%% main_LeZW
%% Add to the path
mfPath = mfilename('fullpath');
addpath(genpath(fileparts(mfPath)));
%% Figure 2
load('NP.mat');
fig2c = plotNP_CPD(NP_MD,NP_OFC);

%% Figure 3

figure3ab = plotNP_SlopeOfCueSI(NP_MD,NP_OFC);
[fig3c,fig3d] = plotNP_SlopeIneterceptOfOutcomeSI_3periods(NP_MD,NP_OFC);

%% Figure 4
load('Calcium.mat');
fig4ef = plotCalcium_Cue(Calcium);
fig4h = plotCalcium_OutcomeSI(Calcium);

%% Figure 5
load('Optotrode.mat');

DI_nonsig_all = Fiber.WellTrain.Nonsig_off_on_all;
DI_sig_all = Fiber.WellTrain.Sig_off_on_all;
fig5de = plotOptotrode_FiberWellTrain(DI_nonsig_all,DI_sig_all,'all');

DI_nonsig_broad = Fiber.WellTrain.Nonsig_off_on_broad;
DI_sig_broad = Fiber.WellTrain.Sig_off_on_broad;
fig5g = plotOptotrode_FiberWellTrain(DI_nonsig_broad,DI_sig_broad,'broad');

DI_nonsig_narrow = Fiber.WellTrain.Nonsig_off_on_narrow;
DI_sig_narrow = Fiber.WellTrain.Sig_off_on_narrow;
fig5i = plotOptotrode_FiberWellTrain(DI_nonsig_narrow,DI_sig_narrow,'narrow');

CueSI_slope_all = Fiber.Learning.CueSI_slope_off_on_all;
CueSI_slope_broad = Fiber.Learning.CueSI_slope_off_on_broad;
CueSI_intercept_all = Fiber.Learning.CueSI_intercept_off_on_all;
CueSI_intercept_broad = Fiber.Learning.CueSI_intercept_off_on_broad;
fig5k = plotOptotrode_FiberLearningCue(CueSI_slope_all,CueSI_intercept_all,'all');
fig5l = plotOptotrode_FiberLearningCue(CueSI_slope_broad,CueSI_intercept_broad,'broad');

OutcomeSI_slope_all = Fiber.Learning.OutcomeSI_slope_off_on_all;
OutcomeSI_slope_broad = Fiber.Learning.OutcomeSI_slope_off_on_broad;
fig5n = plotOptotrode_FiberLearningOutcome(OutcomeSI_slope_all,'all');
fig5o = plotOptotrode_FiberLearningOutcome(OutcomeSI_slope_broad,'broad');


%% Figure 7
DI_nonsig_broad = PV.WellTrain.Nonsig_off_on_broad;
DI_sig_broad = PV.WellTrain.Sig_off_on_broad;
fig7d = plotOptotrode_PVWellTrain(DI_nonsig_broad,DI_sig_broad,'broad');


CueSI_slope_off_on_broad = PV.Learning.CueSI_slope_off_on_broad;
Intercept_slope_off_on_broad = PV.Learning.CueSI_intercept_off_on_broad;
fig7g = plotOptotrode_PVLearningCue(CueSI_slope_off_on_broad,Intercept_slope_off_on_broad);

OutcomeSI_slope_broad = PV.Learning.OutcomeSI_slope_off_on_broad;
fig7j = plotOptotrode_PVLearningOutcome(OutcomeSI_slope_broad);













