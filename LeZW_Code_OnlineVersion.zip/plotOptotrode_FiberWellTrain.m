function fig1 = plotOptotrode_FiberWellTrain(Nonsig,Sig,CellType)
% Input: 1. Nonsig & Sig are an nUnit x 2 matrix, where the first column is the data points when the laser is off, and the second column is the data points when the laser is on.
%        2. CellType must be "all" or "broad" or "narrow"
% Output: figure


fig1=figure('Color','w','Position',[100 100 1000 400]);
subplot(1,2,1);hold on;box off;
scatter(Nonsig(:,1),Nonsig(:,2),'k');
scatter(Sig(:,1),Sig(:,2),'filled','k');
axis square;
plot([-1 1],[-1 1],'--r');
plot([0 0],[-1 1],'--r');
plot([-1 1],[0 0],'--r');
set(gca,'XLim',[-1 1],'YLim',[-1 1],'XTick',-1:1:1,'YTick',-1:1:1);
xlabel('DI (laser off)');
ylabel('DI (laser on)');
if strcmp(CellType,'all')
    title('Broad-spiking & narrow-spiking cells');
    sgtitle('fig. 5d-e');
elseif strcmp(CellType,'broad')
    title('Broad-spiking cells');
    sgtitle('fig. 5g');
elseif strcmp(CellType,'narrow')
    title('Narrow-spiking cells');
    sgtitle('fig. 5i');
end


Sig_neg_DI_id = find(Sig(:,1)<0);
Sig_pos_DI_id = find(Sig(:,1)>=0);
if ~isempty(Sig_neg_DI_id)
    subplot(1,4,3);hold on;box off;
    [mean_off,se_off]=mean_se(Sig(Sig_neg_DI_id,1));
    [mean_on,se_on]=mean_se(Sig(Sig_neg_DI_id,2));
    bar(1,mean_off,'FaceColor','none');
    bar(2,mean_on,'FaceColor','none');
    errorbar(1,mean_off,se_off,'CapSize',0);
    errorbar(2,mean_on,se_on,'CapSize',0);
    set(gca,'XLim',[0.3 2.7],'XTick',1:2,'XTickLabel',{'Off','On'});
    ylabel('DI');
    title({['Sig. DI<0'];['(laser off)']});
end
if ~isempty(Sig_pos_DI_id)
    subplot(1,4,4);hold on;box off;
    [mean_off,se_off]=mean_se(Sig(Sig_pos_DI_id,1));
    [mean_on,se_on]=mean_se(Sig(Sig_pos_DI_id,2));
    bar(1,mean_off,'FaceColor','none');
    bar(2,mean_on,'FaceColor','none');
    errorbar(1,mean_off,se_off,'CapSize',0);
    errorbar(2,mean_on,se_on,'CapSize',0);
    set(gca,'XLim',[0.3 2.7],'XTick',1:2,'XTickLabel',{'Off','On'});
    ylabel('DI');
    title({['Sig. DI>=0'];['(laser off)']});
end



end

