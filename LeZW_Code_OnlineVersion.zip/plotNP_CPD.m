function fig2c = plotNP_CPD(NP_MD,NP_OFC)
%UNTITLED9 此处显示有关此函数的摘要
%   此处显示详细说明
MD = NP_MD.nBlock.CPD;
OFC = NP_OFC.nBlock.CPD;
[MD_rm_cue_CPD_unit_ave_M,MD_rm_cue_CPD_unit_ave_SE ] = mean_se(MD(:,1));
[MD_rm_outcome_CPD_unit_ave_M,MD_rm_outcome_CPD_unit_ave_SE ] = mean_se(MD(:,2));
[MD_rm_lick_CPD_unit_ave_M,MD_rm_lick_CPD_unit_ave_SE ] = mean_se(MD(:,3));
[OFC_rm_cue_CPD_unit_ave_M,OFC_rm_cue_CPD_unit_ave_SE ] = mean_se(OFC(:,1));
[OFC_rm_outcome_CPD_unit_ave_M,OFC_rm_outcome_CPD_unit_ave_SE ] = mean_se(OFC(:,2));
[OFC_rm_lick_CPD_unit_ave_M,OFC_rm_lick_CPD_unit_ave_SE ] = mean_se(OFC(:,3));
fig2c=figure('Color','w','Position',[30 677 802 286]);
% each data point is a session
subplot(121);
hold on;
hb = bar([1:3],[MD_rm_cue_CPD_unit_ave_M MD_rm_outcome_CPD_unit_ave_M MD_rm_lick_CPD_unit_ave_M],0.5);
set(hb,'FaceColor','#F8C0B1','EdgeColor','r');
he=errorbar_2([1:3],[MD_rm_cue_CPD_unit_ave_M MD_rm_outcome_CPD_unit_ave_M MD_rm_lick_CPD_unit_ave_M],...
    [MD_rm_cue_CPD_unit_ave_SE MD_rm_outcome_CPD_unit_ave_SE MD_rm_lick_CPD_unit_ave_SE]);
set(he(1),'color','r');
set(he(2),'color','r','LineStyle','none');
set(gca,'YLim',[0 0.06]);
title('MD');set(gca,'XTick',1:3,'XTickLabel',{'Cue','Outcome','Lick'});
ylabel('CPD');
subplot(122);
hold on;
hb = bar([1:3],[OFC_rm_cue_CPD_unit_ave_M OFC_rm_outcome_CPD_unit_ave_M OFC_rm_lick_CPD_unit_ave_M],0.5);
set(hb,'FaceColor','#89D6B4','EdgeColor','r');
he=errorbar_2([1:3],[OFC_rm_cue_CPD_unit_ave_M OFC_rm_outcome_CPD_unit_ave_M OFC_rm_lick_CPD_unit_ave_M],...
    [OFC_rm_cue_CPD_unit_ave_SE OFC_rm_outcome_CPD_unit_ave_SE OFC_rm_lick_CPD_unit_ave_SE]);
set(he(1),'color','r');
set(he(2),'color','r','LineStyle','none');
set(gca,'YLim',[0 0.09]);
title('OFC');set(gca,'XTick',1:3,'XTickLabel',{'Cue','Outcome','Lick'});
ylabel('CPD');

sgtitle('fig. 2c')
end

