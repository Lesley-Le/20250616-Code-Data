function fig1 = plotCalcium_OutcomeSI(Calcium)
%UNTITLED11 此处显示有关此函数的摘要
%   此处显示详细说明
OutcomeSI_slope = Calcium.Slope_OutcomeSI_3periods;

fig1=figure('Color','w','Position',[100 100 1000 350]);
subplot(1,2,1);box off; hold on;
mean_outcomeSI_slope = mean(OutcomeSI_slope);
p_outcomeSI = signrank(OutcomeSI_slope);
nUnit_Calcium = length(OutcomeSI_slope);
a = histcounts(OutcomeSI_slope,-1.4:0.2:1)/nUnit_Calcium;
Timestamps =-1.4+0.2/2:0.2:1-0.2/2;
bar(Timestamps,a);
hold on;
plot([0 0],ylim,'--r');
ylabel('Fraction of cells');
xlabel('Slope of cueSI');
set(gca,'YLim',[0 0.35]);
tit_txt = sprintf('n=%.3g;mean=%.3f;signrank0=%.3e',nUnit_Calcium,mean_outcomeSI_slope,p_outcomeSI);
title(tit_txt);
subplot(1,2,2);
nOutcomeSI_posSlope = length(find(OutcomeSI_slope>=0));
nOutcomeSI_negSlope = length(find(OutcomeSI_slope<0));
a = nOutcomeSI_posSlope;b = nOutcomeSI_negSlope;
p = pie([a,b]);
cm = [155, 93, 229;254, 228, 64]/255;
colormap(cm);
pText = findobj(p,'Type','text');
percentValues = get(pText,'String');
pText(1).String = strcat(num2str(a),'/',num2str(a+b),' (',...
    percentValues{1,1},')');
pText(2).String = strcat(num2str(b),'/',num2str(a+b),' (',...
    percentValues{2,1},')');
pText(1).FontSize = 12;pText(2).FontSize = 12;
legend('Pos','Neg');
title('Calcium outcomeSI slope');

sgtitle('fig. 4h')
end

