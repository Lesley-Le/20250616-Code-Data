function fig1 = plotOptotrode_FiberLearningCue(Slope,Intercept,CellType)
% Input: 1. Slope & Intercept are an nUnit x 2 matrix, where the first column is the data points when the laser is off, and the second column is the data points when the laser is on.
%        2. CellType must be "all" or "broad" or "narrow"
% Output: figure


fig1=figure('Color','w','Position',[100 100 700 350]);
subplot(1,2,1);hold on; box off;
off = Slope(:,1);on = Slope(:,2);
mean_off = mean(off,1);sem_off = std(off)/sqrt(size(off,1));
mean_on = mean(on,1);sem_on = std(on)/sqrt(size(on,1));
[mean_off,sem_off] = mean_se(off);
[mean_on,sem_on] = mean_se(on);
bar(1,mean_off,'FaceColor','non');
bar(2,mean_on,'FaceColor','non');
errorbar(1,mean_off,sem_off,'CapSize',0);
errorbar(2,mean_on,sem_on,'CapSize',0);
set(gca,'XLim',[0.3 2.7],'XTick',1:2,'XTickLabel',{'Off','On'});
ylabel('Slope of cue SI');


subplot(1,2,2);hold on; box off;
off = Intercept(:,1);on = Intercept(:,2);
mean_off = mean(off,1);sem_off = std(off)/sqrt(size(off,1));
mean_on = mean(on,1);sem_on = std(on)/sqrt(size(on,1));
[mean_off,sem_off] = mean_se(off);
[mean_on,sem_on] = mean_se(on);
bar(1,mean_off,'FaceColor','non');
bar(2,mean_on,'FaceColor','non');
errorbar(1,mean_off,sem_off,'CapSize',0);
errorbar(2,mean_on,sem_on,'CapSize',0);
set(gca,'XLim',[0.3 2.7],'XTick',1:2,'XTickLabel',{'Off','On'});
ylabel('Intercept of cue SI');

if strcmp(CellType,'all')
    sgtitle({['fig. 5k'];['Broad-spiking & narrow-spiking cells']});
elseif strcmp(CellType,'broad')
    sgtitle({['fig. 5l'];['Broad-spiking cells']});
end


end

