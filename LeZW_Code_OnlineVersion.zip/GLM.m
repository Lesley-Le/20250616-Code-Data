%% GLM
    for neu=1:nUnit
        for bln=1:nBlock
            nTrial_X_Y = [];
            % nTrial_X_Y is an n-by-1 structure array where each element contains 9 fields.
            % Structure fields: 1) Spike; 2) Lick rate; 3) go stimulus; 4)no-go stimulus;
            %  5)Hit; 6)CR; 7)FA; 8)Miss; 9)Resp win onset cue
            % All fields in all trials maintain consistent dimensionality of n bins.
            % Example: 10s trial / 250ms bins = 40 bins per field (all fields equal length)
            for iTrial = 1:nTrial_perBlock
                % Spk_binned & Lick_binned: spike PSTH & lick PSTH
                nTrial_X_Y(iTrial).Spk_binned = Spk_binned;
                nTrial_X_Y(iTrial).LickRate_binned = Lick_binned;
                % Fields 3-9: Binary encoding (1 = event present in bin, 0 = event absent)
                nTrial_X_Y(iTrial).go_binned = go_binned;
                nTrial_X_Y(iTrial).nogo_binned = nogo_binned;
                nTrial_X_Y(iTrial).hit_binned = hit_binned;
                nTrial_X_Y(iTrial).CR_binned = CR_binned;
                nTrial_X_Y(iTrial).fa_binned = fa_binned;
                nTrial_X_Y(iTrial).miss_binned = miss_binned;
                nTrial_X_Y(iTrial).gocue_binned = gocue_binned;

            end

            GLM_Y = vertcat(nTrial_X_Y.Spk_binned);
            GLM_X(:,1) = vertcat(nTrial_X_Y.go_binned);
            GLM_X(:,2) = vertcat(nTrial_X_Y.nogo_binned);
            GLM_X(:,3) = vertcat(nTrial_X_Y.LickRate_binned);
            GLM_X(:,4) = vertcat(nTrial_X_Y.hit_binned);
            GLM_X(:,5) = vertcat(nTrial_X_Y.CR_binned);
            GLM_X(:,6) = vertcat(nTrial_X_Y.fa_binned);
            GLM_X(:,7) = vertcat(nTrial_X_Y.miss_binned);
            GLM_X(:,8) = vertcat(nTrial_X_Y.gocue_binned);
            c = GLM_X;
            %%%%%%%%%%%%%%%%%% GLM %%%%%%%%%%%%%%%%%%%%
            
            mdl=fitglm(c,GLM_Y,'linear','Distribution','poisson');
            
            B0{neu}(bln)=mdl.Coefficients.Estimate(1);
            B{neu}(bln,:)=mdl.Coefficients.Estimate(2:9);  % B{i}: (block个数，event个数)
            p{neu}(bln,:)=mdl.Coefficients.pValue;
            t{neu}(bln,:)=mdl.Coefficients.tStat;
            SE{neu}(bln,:)=mdl.Coefficients.SE;


            Y_Estimated{neu,bln}=glmval(mdl.Coefficients.Estimate,GLM_X,'log');% log for poisson, identity for normal
        end
 end

