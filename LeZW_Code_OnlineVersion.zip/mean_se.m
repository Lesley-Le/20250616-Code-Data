
function [meanr, ser]=mean_se(r,method)
if nargin<2 
    method='mean';
end
if size(r,1)*size(r,2)==size(r,2)
    r=r(:);
end
if strcmp(method,'mean')
    meanr=mean(r);
elseif strcmp(method,'median')
    meanr=median(r);
end
ser=std(r)/sqrt(size(r,1)); 