function fig1 = plotOptotrode_FiberLearningOutcome(Slope,CellType)
%UNTITLED14 此处显示有关此函数的摘要
%   此处显示详细说明



nUnit = size(Slope,1);
fig1 = figure('Color','w','Position', [139 107.6667 800 342]);
subplot(1,2,1);box off;hold on;
for iUnit = 1:nUnit
    if Slope(iUnit,1)>0
        plot([1 2],[Slope(iUnit,1) Slope(iUnit,2)],'-r','LineWidth',1); 
    else
        plot([1 2],[Slope(iUnit,1) Slope(iUnit,2)],'-k','LineWidth',1); 
    end
end
set(gca,'XLim',[0.75 2.25],'XTick',[1 2],'XTickLabel',{'Laser off','Laser on'});
plot(xlim,[0 0],'--b','LineWidth',1);
ylabel('Slope of outcome SI');
if strcmp(CellType,'all')
    title('Broad-spiking & narrow-spiking cells');
    sgtitle('fig. 5n');
elseif strcmp(CellType,'broad')
    title('Broad-spiking cells');
    sgtitle('fig. 5o');
end

outcomeSlope_off_pos_id = find(Slope(:,1)>=0);
outcomeSlope_off_neg_id = find(Slope(:,1)<0);
subplot(1,4,3);hold on; box off;
off = Slope(outcomeSlope_off_pos_id,1);on = Slope(outcomeSlope_off_pos_id,2);
mean_off = mean(off,1);sem_off = std(off)/sqrt(size(off,1));
mean_on = mean(on,1);sem_on = std(on)/sqrt(size(on,1));
[mean_off,sem_off] = mean_se(off);
[mean_on,sem_on] = mean_se(on);
bar(1,mean_off,'FaceColor','r');
bar(2,mean_on,'FaceColor','r');
errorbar(1,mean_off,sem_off,'CapSize',0);
errorbar(2,mean_on,sem_on,'CapSize',0);
set(gca,'XLim',[0.3 2.7],'XTick',1:2,'XTickLabel',{'Off','On'});
ylabel('Slope of outcome SI');

subplot(1,4,4);hold on; box off;
off = Slope(outcomeSlope_off_neg_id,1);on = Slope(outcomeSlope_off_neg_id,2);
mean_off = mean(off,1);sem_off = std(off)/sqrt(size(off,1));
mean_on = mean(on,1);sem_on = std(on)/sqrt(size(on,1));
bar(1,mean_off,'FaceColor',[128,128,128]/255);
bar(2,mean_on,'FaceColor',[128,128,128]/255);
errorbar(1,mean_off,sem_off,'CapSize',0);
errorbar(2,mean_on,sem_on,'CapSize',0);
set(gca,'XLim',[0.3 2.7],'XTick',1:2,'XTickLabel',{'Off','On'});
ylabel('Slope of outcome SI');


end

