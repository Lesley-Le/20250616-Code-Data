function fig1 = plotCalcium_Cue(Calcium)
%UNTITLED10 此处显示有关此函数的摘要
%   此处显示详细说明
CueSI_slope = Calcium.Slope_CueSI_3periods;
prefB_slope = Calcium.Slope_prefBeta_3periods;
nonprefB_slope = Calcium.Slope_nonprefBeta_3periods;

fig1=figure('Color','w','Position',[100 100 1000 400]);
subplot(1,2,1);box off; hold on;
max_SI = ceil(max(CueSI_slope)*10)/10;
min_SI = floor(min(CueSI_slope)*10)/10;
mean_cueSI_slope = mean(CueSI_slope);
p_cueSI = signrank(CueSI_slope);
nUnit_Calcium = length(CueSI_slope);
a = histcounts(CueSI_slope,min_SI:0.2:max_SI)/nUnit_Calcium;
Timestamps = min_SI+0.2/2:0.2:max_SI-0.2/2;
bar(Timestamps,a);
hold on;
plot([0 0],ylim,'--r');
ylabel('Fraction of cells');
xlabel('Slope of cueSI');
set(gca,'YLim',[0 0.25]);
tit_txt = sprintf('n=%.3g;mean=%.3f;signrank0=%.3e',nUnit_Calcium,mean_cueSI_slope,p_cueSI);
title(tit_txt);
subplot(1,2,2);box off;hold on;
[mean_pref,sem_pref] = mean_se(prefB_slope);
[mean_nonpref,sem_nonpref] = mean_se(nonprefB_slope);
p_pref = signrank(prefB_slope);
p_nonpref = signrank(nonprefB_slope);
bar(1,mean_pref,'FaceColor','#7FC7C4');
hold on;
errorbar(1,mean_pref,sem_pref,'CapSize',0);
bar(2,mean_nonpref,'FaceColor','#D4A5C3');
errorbar(2,mean_nonpref,sem_nonpref,'CapSize',0);
set(gca,'YLim',[-0.02,0.02],'XLim',[0.25 2.75],'XTick',1:2,'XTickLabel',{'prefB','nonprefB'});
ylabel('slope of beta');
tit_txt = sprintf('p_pref=%.3e;p_nonpref=%.3e',p_pref,p_nonpref);
title(tit_txt);

sgtitle('fig. 4e-f')
end

