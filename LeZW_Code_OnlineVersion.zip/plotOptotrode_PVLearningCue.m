function fig1 = plotOptotrode_PVLearningCue(Slope,Intercept)
% Input: 1. Slope & Intercept are an nUnit x 2 matrix, where the first column is the data points when the laser is off, and the second column is the data points when the laser is on.
%        2. CellType must be "all" or "broad" or "narrow"
% Output: figure


fig1=figure('Color','w','Position',[100 100 1000 350]);
subplot(1,3,1);hold on;box off;
scatter(Slope(:,1),Slope(:,2));
axis square;
plot([-1.5 1.5],[-1.5 1.5],'--r');
set(gca,'XLim',[-1.5 2],'YLim',[-1.5 2],'XTick',-1.5:1.5:1.5,'YTick',-1.5:1.5:1.5);
xlabel('Laser off');
ylabel('Laser on');
title({['Slope of cue SI'];['Broad-spiking cells']});

subplot(1,3,2);hold on; box off;
off = Slope(:,1);on = Slope(:,2);
mean_off = mean(off,1);sem_off = std(off)/sqrt(size(off,1));
mean_on = mean(on,1);sem_on = std(on)/sqrt(size(on,1));
[mean_off,sem_off] = mean_se(off);
[mean_on,sem_on] = mean_se(on);
bar(1,mean_off,'FaceColor','non');
bar(2,mean_on,'FaceColor','non');
errorbar(1,mean_off,sem_off,'CapSize',0);
errorbar(2,mean_on,sem_on,'CapSize',0);
set(gca,'XLim',[0.3 2.7],'XTick',1:2,'XTickLabel',{'Off','On'});
ylabel('Slope of cue SI');


subplot(1,3,3);hold on; box off;
off = Intercept(:,1);on = Intercept(:,2);
mean_off = mean(off,1);sem_off = std(off)/sqrt(size(off,1));
mean_on = mean(on,1);sem_on = std(on)/sqrt(size(on,1));
[mean_off,sem_off] = mean_se(off);
[mean_on,sem_on] = mean_se(on);
bar(1,mean_off,'FaceColor','non');
bar(2,mean_on,'FaceColor','non');
errorbar(1,mean_off,sem_off,'CapSize',0);
errorbar(2,mean_on,sem_on,'CapSize',0);
set(gca,'XLim',[0.3 2.7],'XTick',1:2,'XTickLabel',{'Off','On'},'YLim',[0 0.4]);
ylabel('Intercept of cue SI');

sgtitle({['fig. 7g'];['Broad-spiking cells']});


end



