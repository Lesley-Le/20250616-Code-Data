function [fig3c,fig3d] = plotNP_SlopeIneterceptOfOutcomeSI_3periods(NP_MD,NP_OFC)
%% plot figure 3a-b

MD_slope = NP_MD.only3periods.outcomeSI_slope;
MD_intercept = NP_MD.only3periods.outcomeSI_intercept;
OFC_slope = NP_OFC.only3periods.outcomeSI_slope;
OFC_intercept = NP_OFC.only3periods.outcomeSI_intercept;

%%
fig3c=figure('Position',[100 100 1000 400],'Color','w');
subplot(1,3,1);hold on;box off;
plot(MD_slope,MD_intercept,'k.');
axis equal;
set(gca,'XLim',[-5 5],'YLim',[-5 5]);
plot(xlim,[0 0],'--r');
plot([0 0],ylim,'--r');
xlabel('Regression slope of outcome SI on d''');
ylabel('Regression intercept of outcome SI vs. d''');
title('MD');
subplot(1,3,2);hold on;box off;
MD_negSlope_id = find(MD_slope<0);
[mean_MD_negSlope,sem_MD_negSlope] = mean_se(MD_slope(MD_negSlope_id,1));
[mean_intercept_MD_negSlope,sem_intercept_MD_negSlope] = mean_se(MD_intercept(MD_negSlope_id));
p_Slope_neg = signrank(MD_slope(MD_negSlope_id));
p_Inter_neg = signrank(MD_intercept(MD_negSlope_id));
nNeg = length(MD_negSlope_id);
bar(1,mean_MD_negSlope,'FaceColor','#F8C0B1');
errorbar(1,mean_MD_negSlope,sem_MD_negSlope,'CapSize',0);
bar(2,mean_intercept_MD_negSlope,'FaceColor','#F8C0B1');
errorbar(2,mean_intercept_MD_negSlope,sem_intercept_MD_negSlope,'CapSize',0);
set(gca,'XTick',1:2,'XLim',[0.25 2.75],'XTickLabel',{'Slope','Intercept'});
% tit_txt = sprintf('Cells with neg. outcomeSI slope\n nNeg=%.3g\nmeanSlope=%.3f,p=%.3e\nmeanInter=%.3f,p=%.3e',nNeg,mean_MD_negSlope,p_Slope_neg,mean_intercept_MD_negSlope,p_Inter_neg);
% title(tit_txt);
set(gca,'YLim',[-0.8 0.8]);

subplot(1,3,3);hold on;box off;
MD_posSlope_id = find(MD_slope>=0);
[mean_MD_posSlope,sem_MD_posSlope] = mean_se(MD_slope(MD_posSlope_id));
[mean_intercept_MD_posSlope,sem_intercept_MD_posSlope] = mean_se(MD_intercept(MD_posSlope_id));
p_Slope_pos = signrank(MD_slope(MD_posSlope_id));
p_Inter_pos = signrank(MD_intercept(MD_posSlope_id));
nPos = length(MD_posSlope_id);
bar(1,mean_MD_posSlope,'FaceColor','#F8C0B1');
errorbar(1,mean_MD_posSlope,sem_MD_posSlope,'CapSize',0);
bar(2,mean_intercept_MD_posSlope,'FaceColor','#F8C0B1');
errorbar(2,mean_intercept_MD_posSlope,sem_intercept_MD_posSlope,'CapSize',0);
set(gca,'XTick',1:2,'XLim',[0.25 2.75],'XTickLabel',{'Slope','Intercept'});
% tit_txt = sprintf('Cells with pos. outcomeSI slope\n nPos=%.3g\nmeanSlope=%.3f,p=%.3e\nmeanInter=%.3f,p=%.3e',nPos,mean_MD_posSlope,p_Slope_pos,mean_intercept_MD_posSlope,p_Inter_pos);
% title(tit_txt);
set(gca,'YLim',[-0.8 0.8]);
sgtitle('fig. 3c');
%%
fig3d=figure('Position',[100 100 1000 400],'Color','w');
subplot(1,3,1);hold on;box off;
plot(OFC_slope,OFC_intercept,'k.');
axis equal;
set(gca,'XLim',[-5 5],'YLim',[-5 5]);
plot(xlim,[0 0],'--r');
plot([0 0],ylim,'--r');
xlabel('Regression slope of outcome SI on d''');
ylabel('Regression intercept of outcome SI vs. d''');
title('OFC');
subplot(1,3,2);hold on;box off;
OFC_negSlope_id = find(OFC_slope<0);
[mean_OFC_negSlope,sem_OFC_negSlope] = mean_se(OFC_slope(OFC_negSlope_id,1));
[mean_intercept_OFC_negSlope,sem_intercept_OFC_negSlope] = mean_se(OFC_intercept(OFC_negSlope_id));
p_Slope_neg = signrank(OFC_slope(OFC_negSlope_id));
p_Inter_neg = signrank(OFC_intercept(OFC_negSlope_id));
nNeg = length(OFC_negSlope_id);
bar(1,mean_OFC_negSlope,'FaceColor','#F8C0B1');
errorbar(1,mean_OFC_negSlope,sem_OFC_negSlope,'CapSize',0);
bar(2,mean_intercept_OFC_negSlope,'FaceColor','#F8C0B1');
errorbar(2,mean_intercept_OFC_negSlope,sem_intercept_OFC_negSlope,'CapSize',0);
set(gca,'XTick',1:2,'XLim',[0.25 2.75],'XTickLabel',{'Slope','Intercept'});
% tit_txt = sprintf('Cells with neg. outcomeSI slope\n nNeg=%.3g\nmeanSlope=%.3f,p=%.3e\nmeanInter=%.3f,p=%.3e',nNeg,mean_OFC_negSlope,p_Slope_neg,mean_intercept_OFC_negSlope,p_Inter_neg);
% title(tit_txt);
set(gca,'YLim',[-0.8 0.8]);

subplot(1,3,3);hold on;box off;
OFC_posSlope_id = find(OFC_slope>=0);
[mean_OFC_posSlope,sem_OFC_posSlope] = mean_se(OFC_slope(OFC_posSlope_id));
[mean_intercept_OFC_posSlope,sem_intercept_OFC_posSlope] = mean_se(OFC_intercept(OFC_posSlope_id));
p_Slope_pos = signrank(OFC_slope(OFC_posSlope_id));
p_Inter_pos = signrank(OFC_intercept(OFC_posSlope_id));
nPos = length(OFC_posSlope_id);
bar(1,mean_OFC_posSlope,'FaceColor','#F8C0B1');
errorbar(1,mean_OFC_posSlope,sem_OFC_posSlope,'CapSize',0);
bar(2,mean_intercept_OFC_posSlope,'FaceColor','#F8C0B1');
errorbar(2,mean_intercept_OFC_posSlope,sem_intercept_OFC_posSlope,'CapSize',0);
set(gca,'XTick',1:2,'XLim',[0.25 2.75],'XTickLabel',{'Slope','Intercept'});
% tit_txt = sprintf('Cells with pos. outcomeSI slope\n nPos=%.3g\nmeanSlope=%.3f,p=%.3e\nmeanInter=%.3f,p=%.3e',nPos,mean_OFC_posSlope,p_Slope_pos,mean_intercept_OFC_posSlope,p_Inter_pos);
% title(tit_txt);
set(gca,'YLim',[-0.8 0.8]);
sgtitle('fig. 3d');
end

